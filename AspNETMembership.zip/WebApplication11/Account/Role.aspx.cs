﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace WebApplication11
{
    public partial class Role : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {

                /*
                Roles.CreateRole("System Admin");
                Roles.CreateRole("Admin");
                Roles.CreateRole("Supervisor");
                Roles.CreateRole("User");
                
                 
                 */
                foreach (string role in Roles.GetAllRoles())
                {
                    ddlRole.Items.Add(new ListItem(role,role));
                }
                ddlRole.Items.Insert(0,new ListItem("Please Select", ""));

                string[] r = Roles.GetRolesForUser();
                if (r != null && r.Length > 0)
                {
                    ddlRole.Items.FindByValue(r[0]).Selected=true;
                }
                
            }
        }
        protected void butSave_Click(object sender, EventArgs e)
        {
            foreach (string role in Roles.GetAllRoles())
            {
                if (Roles.IsUserInRole(role))
                {
                    Roles.RemoveUserFromRole(User.Identity.Name, role);
                }
            }
            
            if (ddlRole.SelectedItem.Value != "")
                Roles.AddUserToRole(User.Identity.Name, ddlRole.SelectedItem.Value);

            lblMessage.Text = "Role Updated";

        }
    }
}