﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Profile;
using System.Web.Security;
using System.Web.Services;

namespace WebApplication11
{
	public partial class Property : System.Web.UI.Page
	{
        ProfileServiceManager p = new ProfileServiceManager();
        MembershipUser MUser;
       // public ProfileBase Profile = new ProfileBase();

		protected void Page_Load(object sender, EventArgs e)
		{

            MUser = Membership.GetUser(true);
           
            if (!this.IsPostBack)
            {

                ProfileBase profile = ProfileBase.Create(MUser.UserName, true);
                txtFirstName.Text = profile.GetPropertyValue("FirstName").ToString();
                txtLastName.Text = profile.GetPropertyValue("LastName").ToString();
                txtAddress1.Text = profile.GetPropertyValue("Description").ToString();
               
            }
            


		}

        protected void butSave_Click(object sender, EventArgs e)
        {

            ProfileBase profile = ProfileBase.Create(MUser.UserName, true);
           
            profile.SetPropertyValue("FirstName", txtFirstName.Text);
          
            profile.SetPropertyValue("LastName", txtLastName.Text);
          
            profile.SetPropertyValue("Description", txtAddress1.Text);
            profile.Save();
            lblMessage.Text = "profile updated";
        }
	}
}